#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : SysgenCryo.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import pyrogue as pr
import time
import math
import numpy as np

class CryoChannel(pr.Device):
    def __init__(   self,
            name        = "Cryo frequency cord",
            description = "Note: This module is read-only with respect to sysgen",
            hidden      = True,
            index       = 0,
            parent      = None,
            **kwargs):
        super().__init__(name=name, description=description, hidden=hidden, **kwargs)

        freqSpanMHz = 9.6
        ##############################
        # Configuration registers (RO from Sysgen)
        ##############################
        i = index
        self.add(pr.LinkVariable(
            name         = "etaMagScaled",
            description  = "ETA mag scaled",
            dependencies = [parent.node(f'etaMag[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*2**-10,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round(value*2**10)), write=write),
            typeStr      = "Float64",
        ))

        self.add(pr.LinkVariable(
            name         = "etaPhaseDegree",
            description  = "ETA phase degrees",
            dependencies = [parent.node(f'etaPhase[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*180*2**-15,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round(value*2**15./180)), write=write),
            typeStr      = "Float64",
        ))

        # Cryo channel frequency word
        self.add(pr.LinkVariable(
            name         = "feedbackEnable",
            description  = "Enable feedback on this channel UFix_1_0",
            variable     = parent.node(f'feedbackEnable[{i}]'),
            typeStr      = "UInt1",
        ))

        self.add(pr.LinkVariable(
            name         = "amplitudeScale",
            description  = "Amplitdue scale UFix_4_0",
            variable     = parent.node(f'amplitudeScale[{i}]'),
            typeStr      = "UInt4",
        ))

        self.add(pr.LinkVariable(
            name         = "centerFrequencyMHz",
            description  = "Center frequency MHz",
            dependencies = [parent.node(f'centerFrequency[{i}]')],
            linkedGet    = lambda var: var.dependencies[0].value()*2**-24*freqSpanMHz,
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int(round((value*2**24./freqSpanMHz))), write=write),
            typeStr      = "Float64",
        ))

        # Cryo channel readback loop filter output
        self.add(pr.LinkVariable(
            name         = "loopFilterOutput",
            description  = "Loop filter output UFix_24_24",
            variable     = parent.node(f'loopFilterOutput[{i}]'),
            typeStr      = "Int24",
        ))

        self.add(pr.LinkVariable(
            name         = "amplitudeReadback",
            description  = "Loop filter output UFix_4_0",
            variable     = parent.node(f'amplitudeScale[{i}]'),
            typeStr      = "UInt4",
        ))

        self.add(pr.LinkVariable(
            name         = "frequencyErrorMHz",
            description  = "Frequency error Fix_24_23",
            mode         = "RO",
            dependencies = [parent.node(f'frequencyError[{i}]')],
            linkedGet    = lambda var, read: var.dependencies[0].get(read=read)*2**-23*freqSpanMHz,
            typeStr      = "Float64",
        ))

        self.add(pr.LinkVariable(
            name         = "frequencyError",
            hidden       = True,
            description  = "Frequency error Fix_24_23",
            mode         = "RO",
            variable     = parent.node(f'frequencyError[{i}]'),
            linkedGet    = lambda var, read: var.dependencies[0].get(read=read),
            typeStr      = "Float64",
        ))



class CryoChannels(pr.Device):
    def __init__(   self,
            name        = "CryoFrequencyBand",
            description = "Note: This module is read-only with respect to sysgen",
            hidden      = False,
            **kwargs):
        super().__init__(name=name, description=description, hidden=hidden, **kwargs)

#        ##############################
#        # Devices
#        ##############################
        for i in range(512):
            # Cryo channel ETA
            self.add(pr.RemoteVariable(
                name         = f'etaMag[{i}]',
                hidden       = True,
                description  = "ETA mag Fix_16_10",
                offset       =  0x0000 + i*4,
                bitSize      =  16,
                bitOffset    =  0,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'etaPhase[{i}]',
                hidden       = True,
                description  = "ETA phase Fix_16_15",
                offset       =  0x0002 + i*4,
                bitSize      =  16,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RW",
            ))

            # Cryo channel frequency word
            self.add(pr.RemoteVariable(
                name         = f'feedbackEnable[{i}]',
                hidden       = True,
                description  = "Enable feedback on this channel UFix_1_0",
                offset       =  0x0800 + i*4,
                bitSize      =  1,
                bitOffset    =  31,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'amplitudeScale[{i}]',
                hidden       = True,
                description  = "Amplitdue scale UFix_4_0",
                offset       =  0x0800 + i*4,
                bitSize      =  4,
                bitOffset    =  24,
                base         = pr.UInt,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'centerFrequency[{i}]',
                hidden       = True,
                description  = "Center frequency Fix_24_23",
                offset       =  0x0800 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RW",
            ))

            self.add(pr.RemoteVariable(
                name         = f'amplitudeReadback[{i}]',
                hidden       = True,
                description  = "Loop filter output UFix_4_0",
                offset       =  0x1000 + i*4,
                bitSize      =  4,
                bitOffset    =  24,
                base         = pr.UInt,
                mode         = "RO",
            ))

            # Cryo channel readback loop filter output
            self.add(pr.RemoteVariable(
                name         = f'loopFilterOutput[{i}]',
                hidden       = True,
                description  = "Loop filter output UFix_24_24",
                offset       =  0x1000 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RO",
            ))

            # Cryo channel readback frequency error
            self.add(pr.RemoteVariable(
                name         = f'frequencyError[{i}]',
                hidden       = True,
                description  = "Frequency error MHz",
                offset       =  0x1800 + i*4,
                bitSize      =  24,
                bitOffset    =  0,
                base         = pr.Int,
                mode         = "RO",
            ))

            self.add(CryoChannel(
                name   = f'CryoChannel[{i}]',
                offset = (i*0x4),
                hidden = False,
                expand = False,
                index  = i,
                parent = self,
            ))

        # make waveform of etaMag 
        self.add(pr.LinkVariable(
            name         = "etaMagArray",
            hidden       = True,
            description  = "eta mag array (scaled)",
            dependencies = [self.node(f'etaMag[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-10 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**10)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of etaPhase 
        self.add(pr.LinkVariable(
            name         = "etaPhaseArray",
            hidden       = True,
            description  = "eta phase array (degree)",
            dependencies = [self.node(f'etaPhase[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*180*2**-15 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**15./180)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of feedbackEnable
        self.add(pr.LinkVariable(
            name         = "feedbackEnableArray",
            hidden       = True,
            description  = "feedback enable array",
            dependencies = [self.node(f'feedbackEnable[{i}]') for i in range(512)],
            linkedGet    = self.getArray,
            linkedSet    = self.setArray,
            typeStr      = "List[UInt1]",
        ))

        # make waveform of amplitudeScale 
        self.add(pr.LinkVariable(
            name         = "amplitudeScaleArray",
            hidden       = True,
            description  = "amplitude scale array (0...15)",
            dependencies = [self.node(f'amplitudeScale[{i}]') for i in range(512)],
            linkedGet    = self.getArray,
            linkedSet    = self.setArray,
            typeStr      = "List[UInt4]",
        ))

        # make waveform of centerFrequencyMHz 
        self.add(pr.LinkVariable(
            name         = "centerFrequencyArray",
            hidden       = True,
            description  = "center frequency array (MHz)",
            dependencies = [self.node(f'centerFrequency[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-24*9.6 for val in dev.getArray(dev, var, read)],
            linkedSet    = lambda dev, var, value: dev.setArray( dev, var, [int(round(val*2**24./9.6)) for val in value]),
            typeStr      = "List[Float64]",
        ))

        # make waveform of frequencyError
        self.add(pr.LinkVariable(
            name         = "frequencyErrorArray",
            hidden       = True,
            description  = "frequency error array (MHz)",
            dependencies = [self.node(f'frequencyError[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-23*9.6 for val in dev.getArray(dev, var, read)],
            typeStr      = "List[Float64]",
        ))

        # make waveform of frequencyError
        self.add(pr.LinkVariable(
            name         = "loopFilterOutputArray",
            hidden       = True,
            description  = "loop filter output array (MHz)",
            dependencies = [self.node(f'loopFilterOutput[{i}]') for i in range(512)],
            linkedGet    = lambda dev, var, read: [val*2**-23*9.6 for val in dev.getArray(dev, var, read)],
            typeStr      = "List[Float64]",
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanChannel",
            description = "etaScan frequency band",
            mode        = "RW",
            value       = 0,
        ))

        # keeps track of whether or not an etaScan is currently
        # in progress.  default zero, meaning scan isn't running
        # currently.  runEtaScan sets it to one while it's scanning
        self.add(pr.LocalVariable(
            name        = "etaScanInProgress",
            description = "etaScan in progress",
            mode        = "RW",
            value       = 0,
        ))

        # make waveform for etaScanFreqs, 1000 will be our max number
        # make sure to initialize with type we want in EPICS (float)
        self.add(pr.LocalVariable(
            name        = "etaScanFreqs",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanResultsImag",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanResultsReal",
            hidden      = True,
            description = "etaScan frequencies",
            mode        = "RW",
            value       = [0.0 for x in range(1000)],
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanDelF",
            description = "etaScan frequencies",
            mode        = "RW",
            value       = 5000,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanDwell",
            description = "etaScan frequencies",
            mode        = "RW",
            value       = 0.0,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanAmplitude",
            description = "number of points to average for etaScan",
            mode        = "RW",
            value       = 0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentMaxIters",
            description = "gradient descent max iterations",
            mode        = "RW",
            value       = 15,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentAverages",
            description = "gradient descent number of averages",
            mode        = "RW",
            value       = 2,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentGain",
            description = "Gradient descent gain",
            mode        = "RW",
            value       = 0.001,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentConvergeHz",
            description = "Use gradient convergence threshold",
            mode        = "RW",
            value       = 500.0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentStepHz",
            description = "Use gradient descent initial step",
            mode        = "RW",
            value       = 5000.0,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentMomentum",
            description = "Use gradient descent momentum",
            mode        = "RW",
            value       = 1,
        ))

        self.add(pr.LocalVariable(
            name        = "gradientDescentBeta",
            description = "Use gradient descent initial step",
            mode        = "RW",
            value       = 0.1,
        ))

        self.add(pr.LocalVariable(
            name        = "etaScanAverages",
            description = "eta scan number of averages",
            mode        = "RW",
            value       = 2,
        ))

        self.add(pr.LocalVariable(
            name        = "debug",
            description = "print debug messages",
            mode        = "RW",
            value       = 0,
        ))



        @self.command(description="Load ETA params")
        def loadTuneFile():

            band     = self.parent.band.get()
            tuneFile = self.parent.parent.tuneFilePath.get() 
            print( "Tuning band " + str(band) + " with tune file: " + tuneFile )

            try:

                tune = np.load( tuneFile ).item()
                tuneBand = tune[band]

                with self.root.updateGroup():

                    drive = tuneBand['drive']

                    # load parameters, don't write to HW yet
                    for r in  tuneBand['resonances']:
                        channel      = tuneBand['resonances'][r]['channel']
                        etaPhase     = tuneBand['resonances'][r]['eta_phase']
                        etaMagScaled = tuneBand['resonances'][r]['eta_scaled']
                        centerFreq   = tuneBand['resonances'][r]['offset']

                        if channel == -1:
                            continue

                        self.CryoChannel[channel].amplitudeScale.set( drive, write=False )
                        self.CryoChannel[channel].centerFrequencyMHz.set( centerFreq, write=False )
                        self.CryoChannel[channel].etaPhaseDegree.set( etaPhase, write=False )
                        self.CryoChannel[channel].etaMagScaled.set( etaMagScaled, write=False )
                        self.CryoChannel[channel].feedbackEnable.set( 1, write=False )

                    # write to HW, block transaction
                    self.writeBlocks()
                    self.verifyBlocks()
                    self.checkBlocks()

            except:
                print("Failed to load tune for band " + str( band ) )

             

        @self.command(description="Run etaScan",)
        def runEtaScan():
            self.etaScanInProgress.set( 1 )

            # defer update callbacks
            with self.root.updateGroup():
                subchan = self.etaScanChannel.get()
                ampl    = self.etaScanAmplitude.get()
                freqs   = self.etaScanFreqs.get()
                # workaround for rogue local variables
                # list objects get written as string, not list of float when set by GUI
                if isinstance(freqs, str):
                    freqs = eval(freqs)
    
                dwell   = self.etaScanDwell.get()
                self.CryoChannel[subchan].amplitudeScale.set( ampl )
                self.CryoChannel[subchan].etaMagScaled.set( 1 )
                self.CryoChannel[subchan].feedbackEnable.set( 0 )
    
                # run scan in phase
                self.CryoChannel[subchan].etaPhaseDegree.set( 0 )
                resultsReal = []
                f           = []
                for freqMHz in freqs:
                    # is there overhead of setting freqMHz if prevFreqMHz == freqMHz
                    # out list of freqs may do several measurements at a single freq
                    # dont' want to write the same value again
                    if f != freqMHz:
                        f = freqMHz
                        self.CryoChannel[subchan].centerFrequencyMHz.set( f )
                    freqError = self.CryoChannel[subchan].frequencyError.get()
                    resultsReal.append( freqError )
    
                # run scan in quadrature
                self.CryoChannel[subchan].etaPhaseDegree.set( -90 )
                resultsImag = []
                f           = []
                for freqMHz in freqs:
                    if f != freqMHz:
                        f = freqMHz
                        self.CryoChannel[subchan].centerFrequencyMHz.set( f )
                    freqError = self.CryoChannel[subchan].frequencyError.get()
                    resultsImag.append( freqError )
               
    
                self.etaScanResultsReal.set( resultsReal )
                self.etaScanResultsImag.set( resultsImag )
    
            self.etaScanInProgress.set( 0 )



        @self.command(description="Set all amplitudeScale values",value=0)
        def setAmplitudeScales(arg):
            for c in self.CryoChannel.values():
                c.amplitudeScale.setDisp(arg, write=False)

            # Commit blocks with bulk background writes
            self.writeBlocks()

            # Verify the blocks with background transactions
            self.verifyBlocks()

            # Check write and verify results
            self.checkBlocks()

        @self.command(description="Run gradient descent",background=True,)
        def runGradientDescent():
           self.etaScanInProgress.set( 1 )

           # defer update callbacks
           with self.root.updateGroup():
               amplitudeScaleArray = np.asarray(self.amplitudeScaleArray.get())
               amplIdx = np.where( amplitudeScaleArray != 0 )

               self.feedbackEnableArray.set( [0 for _ in range(512)] )

               self.etaMagArray.set( [1 for _ in range(512)] )

               freq = np.asarray( self.centerFrequencyArray.get() )
               iters     = 0
               max_iters = 10
               l         = 0.005

               # get nominal response
               prevDf   = np.zeros( np.shape(freq) )
               self.etaPhaseArray.set( [0 for _ in range(512)] )
               prevResp = 1j*np.asarray(self.frequencyErrorArray.get(read=True))
               self.etaPhaseArray.set( [-90 for _ in range(512)] )
               prevResp += np.asarray(self.frequencyErrorArray.get(read=True))

               # get response 5kHz away
               currDf           = np.zeros( np.shape(freq) )
               currDf[amplIdx]  = 0.005
               self.centerFrequencyArray.set( freq + currDf )
               self.etaPhaseArray.set( [0 for _ in range(512)] )
               currResp = 1j*np.asarray(self.frequencyErrorArray.get(read=True))
               self.etaPhaseArray.set( [-90 for _ in range(512)] )
               currResp += np.asarray(self.frequencyErrorArray.get(read=True))

               step = currDf - prevDf

               while iters < max_iters:
                   step      = currDf - prevDf 
                   prevDf = currDf
                   currDf[amplIdx] -= l * ( np.abs(currResp[amplIdx]) - np.abs(prevResp[amplIdx]) ) / step[amplIdx]
                   prevResp = currResp
                   self.centerFrequencyArray.set( freq + currDf )
                   self.etaPhaseArray.set( [0 for _ in range(512)] )
                   currResp = 1j*np.asarray(self.frequencyErrorArray.get(read=True))
                   self.etaPhaseArray.set( [-90 for _ in range(512)] )
                   currResp += np.asarray(self.frequencyErrorArray.get(read=True))
                   iters += 1
                   

           self.etaScanInProgress.set( 0 )

        @self.command(description="Run serial gradient descent",background=True,)
        def runSerialGradientDescent():

           def calcGrad(root, channel, centerFrequencyMHz, measDf, numAverages):
               df = measDf
               root.CryoChannel[channel].centerFrequencyMHz.set( centerFrequencyMHz + df )
               root.CryoChannel[channel].etaPhaseDegree.set( 0 )
               posResp = np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
               root.CryoChannel[channel].etaPhaseDegree.set( 90 )
               posResp += 1j*np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])

               root.CryoChannel[channel].centerFrequencyMHz.set( centerFrequencyMHz - df )
               root.CryoChannel[channel].etaPhaseDegree.set( 0 )
               negResp = np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
               root.CryoChannel[channel].etaPhaseDegree.set( 90 )
               negResp += 1j*np.mean([root.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])

               grad = ( np.abs(posResp) - np.abs(negResp) ) / ( 2*df )

               return grad

           if self.etaScanInProgress.get() == 1:
               pass
           else:
               self.etaScanInProgress.set( 1 )

               # defer update callbacks
               with self.root.updateGroup():
                   iters       = 0
                   maxIters    = self.gradientDescentMaxIters.get() 
                   l           = self.gradientDescentGain.get()
                   numAverages = self.gradientDescentAverages.get()
                   momentum    = self.gradientDescentMomentum.get() 
                   initialStep = self.gradientDescentStepHz.get()*1e-6
                   converge    = self.gradientDescentConvergeHz.get()*1e-6
                   beta        = self.gradientDescentBeta.get()
                   debug       = self.debug.get()

                   amplitudeScale = self.amplitudeScaleArray.get()

                   freq           = self.centerFrequencyArray.get()

                   self.feedbackEnableArray.set( [0 for _ in range(512)] )

                   self.amplitudeScaleArray.set( [0 for _ in range(512)] )

                   self.etaMagArray.set( [1 for _ in range(512)] )

                   self.etaPhaseArray.set( [0 for _ in range(512)] )

                   channels = np.where( np.asarray(amplitudeScale) != 0 )

                   for channel in channels[0]:
                       if ( debug == True):
                           print(" ")
                           print(" ")
                           print("Tuning channel " + str(channel))
                           print(" ")
                           print(" ")
                       prevDf = 0
                       currDf = 0
                       self.CryoChannel[channel].amplitudeScale.set( amplitudeScale[channel] )

                       v     = 0
                       iters = 0
                       cache = 0
                       complete = False
                       while (iters < maxIters):
                           #print( str(np.abs(currResp)) + ", " + str(currDf) + ", " + str(step) )
                           prevDf = currDf
                           dx     = calcGrad( self, channel, freq[channel] + currDf, initialStep, numAverages ) # center difference
                           if momentum == 1:
                               v = beta*v + (1-beta)* l * dx
                               currDf -= v
                           else:
                               #cache   += dx**2
                               cache   = beta * cache + (1 - beta) * dx**2
                               currDf -= l * dx / np.sqrt( cache + 1e-8 )
                           step   = currDf - prevDf
                           if ( debug == True ):
                               print("Grad is " + str(dx) + ", step is " + str(step) + " currDf is " + str(currDf))
                           if np.abs(step) < converge:
                               complete = True
                               self.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] + currDf )
                               break
                           iters += 1

                           if ( ( ( freq[channel] + currDf ) > 2.4e6 ) | ( ( freq[channel] + currDf ) < -2.4e6 ) ):
                               self.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] )
                               print("Channel " + str(channel) + " failed to converge")
                               break

                       if ( debug == True ):
                           if (complete == False):
                               print("Channel " + str(channel) + " failed to converge")
                           else:
                               print("Channel " + str(channel) + " converged after " + str(iters) + " iterations")
            

                       self.CryoChannel[channel].amplitudeScale.set( 0 )

                   self.amplitudeScaleArray.set( amplitudeScale )

               self.etaScanInProgress.set( 0 )


        @self.command(description="Run serial eta scan",background=True,)
        def runSerialEtaScan():

           self.etaScanInProgress.set( 1 )

           # defer update callbacks
           with self.root.updateGroup():
               delF            = self.etaScanDelF.get()*1e-6

               numAverages     = self.etaScanAverages.get()

               amplitudeScale  = self.amplitudeScaleArray.get()

               freq            = self.centerFrequencyArray.get()

               self.feedbackEnableArray.set( [0 for _ in range(512)] )

               self.etaMagArray.set( [1 for _ in range(512)] )

               self.etaPhaseArray.set( [0 for _ in range(512)] )

               self.amplitudeScaleArray.set( [0 for _ in range(512)] )

               channels = np.where( np.asarray(amplitudeScale) != 0 )

               for channel in channels[0]:
                   self.CryoChannel[channel].amplitudeScale.set( amplitudeScale[channel] )
                   imag = np.mean([self.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                   self.CryoChannel[channel].etaPhaseDegree.set( -90 )
                   real = np.mean([self.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                   etaPhaseDegree = np.arctan2(imag, real)*180/np.pi
                   if etaPhaseDegree > 180:
                      etaPhaseDegree = etaPhaseDegree - 360
                   elif etaPhaseDegree < -180:
                      etaPhaseDegree = etaPhaseDegree + 360
                   self.CryoChannel[channel].etaPhaseDegree.set( etaPhaseDegree )

                   self.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] + delF )
                   posError = np.mean([self.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                   self.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] - delF )
                   negError = np.mean([self.CryoChannel[channel].frequencyErrorMHz.get(read=True) for _ in range(numAverages)])
                   self.CryoChannel[channel].centerFrequencyMHz.set( freq[channel] )
                   try:
                       etaMagScaled = 2*delF / ( posError - negError )
                       if etaMagScaled < 0:
                           etaMagScaled = np.abs( etaMagScaled )
                           if etaPhaseDegree > 0:
                               etaPhaseDegree = etaPhaseDegree - 180
                           else:
                               etaPhaseDegree = etaPhaseDegree + 180                   
                           
                   except:
                       etaMagScaled=1
                       print("!!! ch%d etaMagScaled inf, setting etaMagScaled=1."%channel)

                   if etaMagScaled>1:
                       print("!!! ch%d etaMagScaled>1, setting etaMagScaled=1."%channel)
                       etaMagScaled=1.

                   self.CryoChannel[channel].etaPhaseDegree.set( etaPhaseDegree )
                   self.CryoChannel[channel].etaMagScaled.set( etaMagScaled )

                   self.CryoChannel[channel].amplitudeScale.set( 0 )

               self.amplitudeScaleArray.set( amplitudeScale )
               time.sleep(0.1)

               for channel in channels[0]:
                   self.CryoChannel[channel].feedbackEnable.set( 1 )

               #feedbackEnable = [0 for _ in range(512)]
               #feedbackEnable[channels[0]] = 1

               #self.feedbackEnableArray.set( feedbackEnable )

           self.etaScanInProgress.set( 0 )

        @self.command(description="Run parallel eta scan",background=True,)
        def runParallelEtaScan():
           self.etaScanInProgress.set( 1 )

           # defer update callbacks
           with self.root.updateGroup():
               delF            = self.etaScanDelF.get()*1e-6
               numAverages     = 10

               amplitudeScaleArray = np.asarray(self.amplitudeScaleArray.get())
               amplIdx = np.where( amplitudeScaleArray == 0 )

               self.feedbackEnableArray.set( [0 for _ in range(512)] )

               self.etaMagArray.set( [1 for _ in range(512)] )

               self.etaPhaseArray.set( [0 for _ in range(512)] )
               time.sleep(0.1)
               imag = np.mean( [ self.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

               self.etaPhaseArray.set( [-90 for _ in range(512)] )
               time.sleep(0.1)
               real = np.mean( [ self.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

               etaPhaseDegree = np.arctan2(imag, real)*180/np.pi

               idx = np.where( etaPhaseDegree > 180 )
               etaPhaseDegree[idx] = etaPhaseDegree[idx] - 360

               idx = np.where( etaPhaseDegree < -180 )
               etaPhaseDegree[idx] = etaPhaseDegree[idx] + 360

               etaPhaseDegree[amplIdx] = 0
               self.etaPhaseArray.set( etaPhaseDegree )

               freq = np.asarray( self.centerFrequencyArray.get() )

               self.centerFrequencyArray.set( freq + delF )
               time.sleep(0.1)
               posError = np.mean( [ self.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )


               self.centerFrequencyArray.set( freq - delF )
               time.sleep(0.1)
               negError = np.mean( [ self.frequencyErrorArray.get(read=True) for _ in range(numAverages) ], axis=0 )

               self.centerFrequencyArray.set( freq )

               etaMagScaled = 2*delF / ( posError - negError )
               idx = np.where( etaMagScaled < 0 )
               etaMagScaled[idx] = np.abs( etaMagScaled[idx] )
               etaPhaseDegree[idx] = etaPhaseDegree[idx] + 180

               idx = np.where( etaPhaseDegree > 180 )
               etaPhaseDegree[idx] = etaPhaseDegree[idx] - 360

               idx = np.where( etaPhaseDegree < -180 )
               etaPhaseDegree[idx] = etaPhaseDegree[idx] + 360

               etaPhaseDegree[amplIdx] = 0
               etaMagScaled[amplIdx] = 0

               self.etaPhaseArray.set( etaPhaseDegree )

               self.etaMagArray.set( etaMagScaled )

               feedbackEnable = [1 for _ in range(512)]
               feedbackEnable[amplIdx] = 0
               self.feedbackEnableArray.set( feedbackEnable )

           self.etaScanInProgress.set( 0 )


    @staticmethod
    def setArray(dev, var, value):
       # workaround for rogue local variables
       # list objects get written as string, not list of float when set by GUI
       if isinstance(value, str):
           value = eval(value)
       for variable, setpoint in zip( var.dependencies, value ):
           variable.set( setpoint, write=False )
       dev.writeBlocks()
       dev.verifyBlocks()
       dev.checkBlocks()

    @staticmethod
    def getArray(dev, var, read):
       if read:
          dev.readBlocks(variable=var.dependencies)
          dev.checkBlocks(variable=var.dependencies)
       return [variable.value() for variable in var.dependencies]


class CryoFreqBand(pr.Device):
    def __init__(   self,
            name        = "SysgenCryoBase",
            bandCenter  = 4250.0,
            description = "Cryo SYSGEN Module",
            band        = 1,
            enableDeps  = None,
            **kwargs):
        super().__init__(name=name, description=description, enableDeps=enableDeps, **kwargs)

        def genCenterFrequencies():
           def bitRevOrder(x):
              length = x.shape[0]
              assert( np.log2(length) == np.floor(np.log2(length)) )

              if length == 1:
                 return x
              else:
                 evenIndex = np.arange(length/2)*2
                 oddIndex  = np.arange(length/2)*2 + 1
                 evens     = bitRevOrder( x[evenIndex.astype(int)] )
                 odds      = bitRevOrder( x[oddIndex.astype(int)] )
                 return np.concatenate([evens, odds])

           fAdc          = 614.4      # digitizer frequency MHz
           fftLen        = 64         # fft length
           nFft          = 2          # interleaved polyphase filter bank
           nTones        = 4          # 4 tones/subband
           bands         = np.arange(64) * fAdc/fftLen
           bandsRevOrder = bands[ bitRevOrder( np.arange(64) ) ]
           bandsTile1    = np.tile(bandsRevOrder, nTones) 
           bandsTile2    = np.concatenate([bandsTile1, bandsTile1 + fAdc/(fftLen*nFft)])
        
           bandsCenter   = bandsTile2
           index         = np.where( bandsCenter > fAdc/2 )
           bandsCenter[index]  = bandsCenter[index] - fAdc
           return bandsCenter.tolist()

        #self.p = parent
        ##############################
        # Freq band parameters
        ##############################

        self.add(pr.LocalVariable(
            name        = "band",
            description = "band",
            mode        = "RO",
            value       = band,
        ))

        self.add(pr.LocalVariable(
            name        = "digitizerFrequencyMHz",
            description = "ADC/DAC sampling rate MHz",
            mode        = "RO",
            value       = 614.4,
        ))

        self.add(pr.LocalVariable(
            name        = "channelFrequencyMHz",
            description = "channel processing rate MHz",
            mode        = "RO",
            value       = 2.4,
        ))

        self.add(pr.LocalVariable(
            name        = "bandCenterMHz",
            description = "bandCenter MHz",
            mode        = "RW",
            value       = bandCenter,
        ))

        self.add(pr.LocalVariable(
            name        = "numberChannels",
            description = "number of channels",
            mode        = "RO",
            value       = 512,
        ))

        self.add(pr.LocalVariable(
            name        = "numberSubBands",
            description = "number of DSP sub bands",
            mode        = "RO",
            value       = 128,
        ))

        self.add(pr.LocalVariable(
            name        = "toneFrequencyOffsetMHz",
            description = "frequency to subband",
            mode        = "RO",
            value       = [round(x,1) for x in genCenterFrequencies()],
        ))

        ##############################
        # Devices
        ##############################
        self.add(CryoChannels(
            name   = 'CryoChannels',
            offset = 0x00010000,
            expand = False,
        ))

        ##############################
        # Registers
        ##############################
        self.add(pr.RemoteVariable(
            name         = "VersionNumber",
            description  = "Version Number",
            offset       =  0x000,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))

        self.add(pr.RemoteVariable(
            name         = "ScratchPad",
            description  = "Scratch Pad Register",
            offset       =  0xFFC,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## config0
        self.add(pr.RemoteVariable(
            name         = "waveformSelect",
            description  = "Select waveform table",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "noiseSelect",
            description  = "Play uniformly distributed PRNG",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "rfEnable",
            description  = "Enable RF output",
            offset       =  0x80,
            bitSize      =  1,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config0  end

## config1
        self.add(pr.RemoteVariable(
            name         = "iqSwapOut",
            description  = "Swap IQ channels on output",
            offset       =  0x84,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "iqSwapIn",
            description  = "Swap IQ channels on input",
            offset       =  0x84,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config1  end

## config2
        self.add(pr.RemoteVariable(
            name         = "refPhaseDelayInt",
            description  = "refPhaseDelay",
            offset       =  0x118,
            hidden       = True,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
   
        self.add(pr.LinkVariable(
            dependencies = [self.refPhaseDelayInt],
            linkedGet    = lambda var: int((var.dependencies[0].value() + 6)/208),
            linkedSet    = lambda var, value, write: var.dependencies[0].set(int((value*208)-6), write=write),
            typeStr      = "UInt4",
            name         = "refPhaseDelay",
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "toneScale",
            description  = "Scale the sum of 16 tones before synthesizer",
            offset       =  0x88,
            bitSize      =  2,
            bitOffset    =  3,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackEnable",
            description  = "Global feedback enable",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  5,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackPolarity",
            description  = "Global feedback polarity",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  6,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "swapDfIQ",
            description  = "Swap DF IQ",
            offset       =  0x88,
            bitSize      =  1,
            bitOffset    =  7,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "statusChannelSelect",
            description  = "Select channel for status registers",
            offset       =  0x88,
            bitSize      =  9,
            bitOffset    =  8,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config2  end

## config3
        self.add(pr.RemoteVariable(
            name         = "feedbackGain",
            description  = "Feedback gain UFix_16_12",
            offset       =  0x8C,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
        self.add(pr.RemoteVariable(
            name         = "feedbackLimit",
            description  = "Feedback limit UFix_16_16",
            offset       =  0x8C,
            bitSize      =  16,
            bitOffset    =  16,
            base         = pr.UInt,
            mode         = "RW",
        ))
## config3  end

## config4
        self.add(pr.RemoteVariable(
            name         = "filterAlpha",
            description  = "IIR filter alpha UFix16_15",
            offset       =  0x90,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## config4 end
        self.add(pr.RemoteVariable(
            name         = "loopFilterOutputSel",
            description  = "Global loop filter out reg.  Select with ",
            offset       =  0x94,
            bitSize      =  7,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "analysisScale",
            description  = "analysis filter bank scale, nominal value is 1",
            offset       =  0x98,
            bitSize      =  2,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "synthesisScale",
            description  = "synthesis filter bank scale, nominal value is 2",
            offset       =  0x98,
            bitSize      =  2,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "decimation",
            description  = "debug decimation rate 0...7",
            offset       =  0x98,
            bitSize      =  3,
            bitOffset    =  4,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "singleChannelReadout",
            description  = "select for single channel readout",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "singleChannelReadoutOpt2",
            description  = "non-decimated single channel readout - rate 307.2e6/128",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  10,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "iqStreamEnable",
            description  = "readout IQ data instead of freq/freqError",
            offset       =  0x9C,
            bitSize      =  1,
            bitOffset    =  11,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "readoutChannelSelect",
            description  = "select for single channel readout",
            offset       =  0x9C,
            bitSize      =  9,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))



        self.add(pr.RemoteVariable(
            name         = "dspReset",
            description  = "reset DSP core",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "dspEnable",
            description  = "Enable DSP core",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  1,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "refPhaseDelayFine",
            description  = "fine delay control (307.2MHz clock)",
            offset       =  0x100,
            bitSize      =  8,
            bitOffset    =  2,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "trigRstDly",
            description  = "Trigger reset delay (2.4MHz ticks)",
            offset       =  0x10C,
            bitSize      =  7,
            bitOffset    =  5,
            base         = pr.UInt,
            mode         = "RW",
        ))


        self.add(pr.RemoteVariable(
            name         = "lmsDelay",
            description  = "Match system latency for LMS feedback (9.6MHz ticks, use multiples of 52)",
            offset       =  0x10C,
            bitSize      =  5,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackStart",
            description  = "Start integration UFix32",
            offset       =  0x110,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "feedbackEnd",
            description  = "End integration UFix32",
            offset       =  0x114,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))
   

        self.add(pr.RemoteVariable(
            name         = "lmsGain",
            description  = "LMS gain, powers of 2",
            offset       =  0x100,
            bitSize      =  3,
            bitOffset    =  10,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable1",
            description  = "Enable 1st harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  16,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable2",
            description  = "Enable 2nd harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  17,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsEnable3",
            description  = "Enable 3rd harmonic tracking",
            offset       =  0x100,
            bitSize      =  1,
            bitOffset    =  18,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.RemoteVariable(
            name         = "lmsFreq",
            description  = "LMS frequency = flux ramp freq * nPhi0",
            offset       =  0x104,
            bitSize      =  24,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

        self.add(pr.LinkVariable(
            name         = "lmsFreqHz",
            description  = "LMS frequency = flux ramp freq * nPhi0",
            dependencies = [self.lmsFreq],
            linkedGet    = lambda: self.lmsFreq.value()*(2**-24)*(9.6*10**6),
            linkedSet    = lambda value, write: self.lmsFreq.set(round(value*(2**24)/(9.6*10**6)), write=write),
            typeStr      = "Float64",
        ))

        self.add(pr.RemoteVariable(
            name         = "streamEnable",
            description  = "Enable streaming",
            offset       =  0x108,
            bitSize      =  1,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RW",
        ))

## status1
        self.add(pr.RemoteVariable(
            name         = "Q",
            description  = "Q readback Fix_16_15",
            offset       =  0x08,
            bitSize      =  16,
            bitOffset    =  0,
            base         = pr.Int,
            mode         = "RO",
##            pollInterval = 1,
        ))
        self.add(pr.RemoteVariable(
            name         = "I",
            description  = "I readback Fix_16_15",
            offset       =  0x08,
            bitSize      =  16,
            bitOffset    =  16,
            base         = pr.Int,
            mode         = "RO",
##            pollInterval = 1,
        ))
## status1 end

## status 2
        self.add(pr.RemoteVariable(
            name         = "dspCounter",
            description  = "32 bit counter, dsp clock domain UFix_32_0",
            offset       =  0x0C,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))
## status2 end
        self.add(pr.RemoteVariable(
            name         = "loopFilterOutput",
            description  = "Loop filter output UFix_32_0",
            offset       =  0x10,
            bitSize      =  32,
            bitOffset    =  0,
            base         = pr.UInt,
            mode         = "RO",
        ))



class SysgenCryo(pr.Device):
    def __init__(   self,
            name        = "SysgenCryo",
            numberPairs = 1,
            enableDeps  = None,
            description = "Cryo SYSGEN Module",
            **kwargs):
        super().__init__(name=name, description=description, **kwargs)

        bandCenters = [4250.0, 4750.0, 5250.0, 5750.0, 6250.0, 6750.0, 7250.0, 7750.0]
        bandOffsets = [0x000000, 0x100000, 0x200000, 0x300000, 0x800000, 0x900000, 0xA00000, 0xB00000]

        ##############################
        # Devices
        ##############################
        for i in range(8):
            enable = None
            if enableDeps != None:
                enable = enableDeps[i]

            self.add(CryoFreqBand(
                name       = ('Base[%d]'%i),
                bandCenter = bandCenters[i],
                band       = i,
                offset     = bandOffsets[i],
                enableDeps = [enable],
                expand     = False,
            ))

        self.add(pr.LocalVariable(
             name        = "tuneFilePath",
             description = "tune file",
             mode        = "RW",
             value       = "",
        ))
