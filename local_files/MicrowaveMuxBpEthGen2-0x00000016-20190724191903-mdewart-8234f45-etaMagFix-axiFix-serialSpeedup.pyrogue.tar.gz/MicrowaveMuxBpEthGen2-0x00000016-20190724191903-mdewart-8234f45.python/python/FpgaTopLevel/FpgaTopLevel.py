#!/usr/bin/env python
#-----------------------------------------------------------------------------
# Title      : PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# File       : AppCore.py
# Created    : 2017-04-03
#-----------------------------------------------------------------------------
# Description:
# PyRogue AMC Carrier Cryo Demo Board Application
#-----------------------------------------------------------------------------
# This file is part of the rogue software platform. It is subject to
# the license terms in the LICENSE.txt file found in the top-level directory
# of this distribution and at:
#    https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html.
# No part of the rogue software platform, including this file, may be
# copied, modified, propagated, or distributed except according to the terms
# contained in the LICENSE.txt file.
#-----------------------------------------------------------------------------

import AppTop as app

class FpgaTopLevel(app.TopLevel):
    def __init__( self, 
        simGui          = False,
        commType        = "eth-rssi-interleaved",
        ipAddr          = "10.0.1.101",
        pcieRssiLink    = 0,        
        disableBay0     = False,
        disableBay1     = False
    ):
        super().__init__(
            simGui          = simGui,
            commType        = commType,
            ipAddr          = ipAddr,
            pcieRssiLink    = pcieRssiLink,              
            numRxLanes      = [(not disableBay0) * 10,    (not disableBay1) * 10],      # 10x JESD, if bay is not disabled
            numTxLanes      = [(not disableBay0) * 10,    (not disableBay1) * 10],      # 10x JES, if bay is not disabled
            numSigGen       = [(not disableBay0) * 2,     (not disableBay1) * 2],       # 2x SIGGE, if bay is not disabled
            sizeSigGen      = [(not disableBay0) * 2**13, (not disableBay1) * 2**13],   # 2^12 buffer siz, if bay is not disabled
            modeSigGen      = [True,True], # True = 32-bit RAM, True =16-bit RAM
            enableBsa       = False,       # BSA not built in FW
            enableMps       = False,       # MPS not built in FW
        )
        
